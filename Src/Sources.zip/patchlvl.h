/* SCMVERSION is a string for the version specifier.  The leading
   number is the major version number, the letter is the revision ("a"
   for alpha release, "b" for beta release, "c", and so on), and the
   trailing number is the patchlevel. */

#ifndef SCMVERSION
#define SCMVERSION "4e1"
#endif
